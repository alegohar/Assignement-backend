const {createSignup, loginwithpassword} = require("../service/service");
// exports.createSignup = async(req,res)=>{
// const {password, user, course, userType} = req.body;
// req.body.userType = "Teacher";
// const signupdata = await createSignup(password, user, course, userType);

// //pass.checkPassword(password, pass.password);
// res.json(signupdata);
// }
exports.StudentSignup = async (req, res) => {
  try {
    // Extracting data from the request body
    const { password, user, course, userType, email } = req.body;

    // Setting userType to "Teacher"
    const userTypeupdate = "Student";

    // Calling createSignup from the service module
    const StudentData = await createSignup(password, user, course, userTypeupdate, email);

    // You don't need to check the password here because createSignup should handle it

    res.json(StudentData);
  } catch (error) {
    console.error("Error in createSignup:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};

    exports.loginwithpassword = async (req, res) => {
      const { id, password } = req.body;
      const { success, message, status } = await loginwithpassword(
        id,
        password
      );
      res.status(status).json({
        success,
        message,
      });
    };