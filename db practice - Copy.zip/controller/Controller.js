const {createSignup, loginwithpassword, submitAssignment} = require("../service/service");
const notifyEmail = require("../mail/notifyEmail");

// exports.createSignup = async(req,res)=>{
// const {password, user, course, userType} = req.body;
// req.body.userType = "Teacher";
// const signupdata = await createSignup(password, user, course, userType);

// //pass.checkPassword(password, pass.password);
// res.json(signupdata);
// }
exports.submitAssignment = async (req, res) => {
  try {
    // Extracting data from the request body
    const { user, course, date, marks, fileurl} = req.body;

    // Setting userType to "Teacher"
    

    // Calling createSignup from the service module
    const studentAssignment = await submitAssignment(user, course, date, marks, fileurl);

    // You don't need to check the password here because createSignup should handle it

    res.json(studentAssignment);
  } catch (error) {
    console.error("Error in createSignup:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};


exports.createSignup = async (req, res) => {
  try {
    // Extracting data from the request body
    const { password, user, course, userType, email } = req.body;

    // Setting userType to "Teacher"
    const updatedUserType = "Teacher";


    // Calling createSignup from the service module
    const teacherData = await createSignup(password, user, course, updatedUserType, email);
    if (teacherData) {console.log(teacherData.email);
      const sent = await notifyEmail({
        email: teacherData.email,
        subject: "Sign up Confirmation",
        isSignup: true,
        isCreateAssignment: false,
        isSubmitAssignment: false,

        // You can customize the email content as needed
        //text: `Thank you for signing up! We're excited to have you.`,
      });

      console.log("Welcome email sent:", sent);
    }
    const { password: _, _id, __v, ...teacherDataWithoutPassword } = teacherData._doc;

    // Create a new array with the modified object
    const arr = [teacherDataWithoutPassword];

    res.json(arr);
  } catch (error) {
    console.error("Error in createSignup:", error);
    res.status(500).json({
      success: false,
      message: "Internal Server Error",
    });
  }
};
    exports.loginwithpassword = async (req, res) => {
      const { email, password } = req.body;
      const logindata = await loginwithpassword(email, password);
            console.log(logindata); 
      if (logindata) {
        const sent = await notifyEmail({
          email: logindata.email,
          subject: "Login Confirmation",
          isSignup: false,
          isCreateAssignment: false,
          isSubmitAssignment: false,
          isloggedin: true,
          // You can customize the email content as needed
          //text: `Thank you for signing up! We're excited to have you.`,
        });
      
        console.log("Login sent:", sent);
      
        res.status(200).json({
          success: true,
          message: "Login successful",
        });
      } else {
        res.status(401).json({
          success: false,
          message: "Login failed. Please check your credentials.",
        });
      }
    }
      exports.data = async (req,res)=>{
        const datarecords = SignupModel.find();
        res.json(datarecords);
        }